# l10n-mx-xml-invoice
Import mx XML invoice to create invoice odoo:

- Valida que el xml corresponda a la empresa receptor
- Valida que el UUID no esté repetido (evitar contabilidad duplicada)
- Valida que la factura no esté cancelada en el SAT
- Crea el proveedor en caso de no encontrarlo en el catálogo
- Valida el monto subtotal con xml
- Valida monto total con xml
- Agrega la fecha del XML a la factura.
- Cuando se valida la factura confirma que la fecha de factura sea la misma que la del XML.
- Se agrego la funcionalidad de cuenta a analítica.
- Informa al los proveedores que fueron creados con un link directo (ver imagen adjunta).
- Cuando uno de los XML tiene algún error la linea se torna de un color diferente (ver imagen adjunta).
- Estados:
  - IMPORT XML:  El usuario puede importar XML.
  - ALL XML ARE VALID: Todos los XML estan correctos.
  - INVOICES CREATED: Todas las facturas están creadas.
  - ERROR: Algún xml tiene un error (no pertenece a la misma compañía o algún error retornado por el SAT).
- Hace varios intentos para buscar un producto:
  - Primero, busca el id del producto con el barcode.
  - Segundo, busca el id del producto con la referencia interna.
  - Tercero, busca el producto por el nombre del producto.
  - Si no se cumplen ningunas de las condiciones anteriores usara la cuenta seleccionada con la descripción del XML.
- Le informa al usuario cuales productos no fueron encontrados con un link directo a dicha factura.
- Tiene un link directo con todas las facturas creadas.
